package com.getui.demo;

/**
 * 此类空实现即可.
 */
public class DemoPushService extends com.igexin.sdk.PushService {
}
