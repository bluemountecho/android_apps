package com.getui.demo.ui.presenter;

/**
 * Time：2020-03-10 on 14:57.
 * Decription:.
 * Author:jimlee.
 */
public interface BaseInteractor {

    void onDestroy();
}
