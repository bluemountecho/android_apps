package com.getui.demo.net.response;

/**
 * Time：2020-03-09 on 17:08.
 * Decription:.
 * Author:jimlee.
 */
public class AuthResp {

    public String result;
    public String auth_token;
}
