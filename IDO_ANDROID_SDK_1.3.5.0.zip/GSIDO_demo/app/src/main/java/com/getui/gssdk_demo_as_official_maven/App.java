package com.getui.gssdk_demo_as_official_maven;

import android.app.Application;

import com.getui.gs.ias.core.GsConfig;
import com.getui.gs.sdk.GsManager;

public class App extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        GsConfig.setDebugEnable(true);
        GsManager.getInstance().init(this);
    }
}
